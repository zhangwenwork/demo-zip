# developer-test-python

All tests are in blog-app
