import datetime as dt

from slugify import slugify

from blog.database import (Model, SurrogatePK, db, Column,
                           reference_col, relationship)


class Comment(Model, SurrogatePK):
    __tablename__ = 'comment'

    id = db.Column(db.Integer, primary_key=True)
    body = Column(db.Text)
    createdAt = Column(db.DateTime, nullable=False, default=dt.datetime.utcnow)
    updatedAt = Column(db.DateTime, nullable=False, default=dt.datetime.utcnow)
    article_id = reference_col('article', nullable=False)

    def __init__(self, article, body, **kwargs):
        db.Model.__init__(self, body=body, article=article, **kwargs)


class Article(SurrogatePK, Model):
    __tablename__ = 'article'

    id = db.Column(db.Integer, primary_key=True)
    slug = Column(db.Text, unique=True)
    title = Column(db.String(100), nullable=False)
    description = Column(db.Text, nullable=False)
    body = Column(db.Text)
    createdAt = Column(db.DateTime, nullable=False, default=dt.datetime.utcnow)
    updatedAt = Column(db.DateTime, nullable=False, default=dt.datetime.utcnow)

    comments = relationship('Comment', backref=db.backref('article'), lazy='dynamic')

    def __init__(self, title, body, description, slug=None, **kwargs):
        db.Model.__init__(self, title=title, description=description, body=body,
                          slug=slug or slugify(title), **kwargs)


