from marshmallow import Schema, fields, pre_load, post_dump

class ArticleSchema(Schema):
    slug = fields.Str()
    title = fields.Str()
    description = fields.Str()
    createdAt = fields.DateTime()
    body = fields.Str()
    updatedAt = fields.DateTime(dump_only=True)
    article = fields.Nested('self', exclude=('article',), default=True, load_only=True)

    @pre_load
    def make_article(self, data, **kwargs):
        return data['article']

    @post_dump(pass_many=True)
    def dump_article(self, data, **kwargs):
        return {'article': data}

    class Meta:
        strict = True


class ArticleSchemas(ArticleSchema):
    # @pre_load
    # def dump_article(self, data, **kwargs):
    #     return {'article': data}

    @post_dump(pass_many=True)
    def dump_articles(self, data, many, **kwargs):
        return {'articles': data, 'articlesCount': len(data["article"])}


class CommentSchema(Schema):
    createdAt = fields.DateTime()
    body = fields.Str()
    updatedAt = fields.DateTime(dump_only=True)
    id = fields.Int()

    # for the envelope
    comment = fields.Nested('self', exclude=('comment',), default=True, load_only=True)

    @pre_load
    def make_comment(self, data, **kwargs):
        return data['comment']

    class Meta:
        strict = True


class CommentsSchema(CommentSchema):


    @post_dump(pass_many=True)
    def make_comment(self, data, many, **kwargs):
        return {'comments': data}


article_schema = ArticleSchema()
articles_schema = ArticleSchemas(many=True)
comment_schema = CommentSchema()
comments_schema = CommentsSchema(many=True)
