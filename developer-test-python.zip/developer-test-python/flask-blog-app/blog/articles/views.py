import datetime as dt

from flask import Blueprint
from flask_apispec import marshal_with, use_kwargs
from marshmallow import fields

from blog.exceptions import InvalidUsage
from .models import Article, Comment
from .serializers import (article_schema, articles_schema, comment_schema,
                          comments_schema)

blueprint = Blueprint('articles', __name__)


##########

@blueprint.route('/api/articles', methods=('GET',))
@use_kwargs({'limit': fields.Int(), 'offset': fields.Int()})
@marshal_with(articles_schema)
def get_articles(limit=20, offset=0):
    res = Article.query

    return res.offset(offset).limit(limit).all()


@blueprint.route('/api/articles', methods=('POST',))
@use_kwargs(article_schema)
@marshal_with(article_schema)
def make_article(body, title, description):
    article = Article(title=title, description=description, body=body)
    article.save()
    return article


@blueprint.route('/api/articles/<slug>', methods=('PUT',))
@use_kwargs(article_schema)
@marshal_with(article_schema)
def update_article(slug, **kwargs):
    article = Article.query.filter_by(slug=slug).first()
    if not article:
        raise InvalidUsage.article_not_found()
    article.update(updatedAt=dt.datetime.utcnow(), **kwargs)
    article.save()
    return article


@blueprint.route('/api/articles/<slug>', methods=('DELETE',))
def delete_article(slug):
    article = Article.query.filter_by(slug=slug).first()
    article.delete()
    return '', 200


@blueprint.route('/api/articles/<slug>', methods=('GET',))
@marshal_with(article_schema)
def get_article(slug):
    article = Article.query.filter_by(slug=slug).first()
    if not article:
        raise InvalidUsage.article_not_found()
    return article

##########
# Comments
##########


@blueprint.route('/api/articles/<slug>/comments', methods=('GET',))
@marshal_with(comments_schema)
def get_comments(slug):
    article = Article.query.filter_by(slug=slug).first()
    if not article:
        raise InvalidUsage.article_not_found()
    return article.comments


@blueprint.route('/api/articles/<slug>/comments', methods=('POST',))

@use_kwargs(comment_schema)
@marshal_with(comment_schema)
def make_comment_on_article(slug, body, **kwargs):
    article = Article.query.filter_by(slug=slug).first()
    if not article:
        raise InvalidUsage.article_not_found()
    comment = Comment(article, body, **kwargs)
    comment.save()
    return comment


@blueprint.route('/api/articles/<slug>/comments/<cid>', methods=('DELETE',))
def delete_comment_on_article(slug, cid):
    article = Article.query.filter_by(slug=slug).first()
    if not article:
        raise InvalidUsage.article_not_found()

    comment = article.comments.filter_by(id=cid).first()
    comment.delete()
    return '', 200
