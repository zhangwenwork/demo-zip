# flask-blog-app

### Run the project

#### Set up evn

- export FLASK_APP=/path/to/autoapp.py

- export FLASK_DEBUG=1

#### DB

- flask db init
- flask db migrate
- flask db upgrade

#### Run

- flask run --with-threads  

#### Run Test

- flask test
