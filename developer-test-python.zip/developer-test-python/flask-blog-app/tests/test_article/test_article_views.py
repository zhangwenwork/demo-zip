# flask-blog-app/tests/test_article/test_article_views.py
from flask import url_for
from datetime import datetime


class TestArticleViews:

    def test_get_articles_by_author(self, testapp):
        for _ in range(2):
            testapp.post_json(url_for('articles.make_article'), {
                "article": {
                    "title": "How to train your dragon {}".format(_),
                    "description": "Ever wonder how?",
                    "body": "You have to believe",
                }
            })

        resp = testapp.get(url_for('articles.get_articles'))
        assert resp.json["articlesCount"] == 2

    def test_make_article(self, testapp):
        resp = testapp.post_json(url_for('articles.make_article'), {
            "article": {
                "title": "How to train your dragon",
                "description": "Ever wonder how?",
                "body": "You have to believe",
            }
        })
        assert resp.json['article']['body'] == 'You have to believe'

    def test_update_article(self, testapp):
        # create an article
        article_resp = testapp.post_json(url_for('articles.make_article'), {
            "article": {
                "title": "How to train your dragon",
                "description": "Ever wonder how?",
                "body": "You have to believe",
            }
        })

        slug = article_resp.json['article']['slug']

        resp = testapp.put_json(url_for('articles.update_article', slug=slug), {
            "article": {
                "body": "change body!",
            }
        })
        assert resp.json['article']['body'] == 'change body!'

    def test_delete_article(self, testapp):
        # create an article
        article_resp = testapp.post_json(url_for('articles.make_article'), {
            "article": {
                "title": "How to train your dragon",
                "description": "Ever wonder how?",
                "body": "You have to believe",
            }
        })

        resp = testapp.get(url_for('articles.get_articles'))
        assert resp.json["articlesCount"] == 1

        slug = article_resp.json['article']['slug']

        testapp.delete_json(url_for('articles.delete_article', slug=slug))
        deleted_resp = testapp.get(url_for('articles.get_articles'))
        assert deleted_resp.json["articlesCount"] == 0

    def test_make_comment_correct_schema(self, testapp):
        article_resp = testapp.post_json(url_for('articles.make_article'), {
            "article": {
                "title": "How to train your dragon",
                "description": "Ever wonder how?",
                "body": "You have to believe",
            }
        })
        slug = article_resp.json['article']['slug']
        testapp.post_json(url_for('articles.make_comment_on_article', slug=slug), {
            "comment": {
                "createdAt": datetime.now().isoformat(),
                "body": "You have to believe",
            }
        })
        resp = testapp.get(url_for('articles.get_comments', slug=slug))
        assert len(resp.json['comments']) == 1
        assert resp.json["comments"][0]["body"] == "You have to believe"
