#flask-blog-app/tests/test_article/test_models.py
import pytest

from blog.articles.models import Article, Comment


@pytest.mark.usefixtures('db')
class TestArticles:
    def test_create_article(self):
        article = Article('title', 'some body', description='some')
        article.save()
        assert article.title == 'title'


@pytest.mark.usefixtures('db')
class TestComment:

    def test_make_comment(self):
        article = Article('title', 'some body', description='some')
        article.save()
        comment = Comment(article, 'some body')
        comment.save()

        assert comment.article == article

    def test_make_comments(self):
        article = Article('title', 'some body', description='some')
        article.save()
        first_comment = Comment(article, 'first comment from someone')
        second_comment = Comment(article, 'second comment from someone')
        first_comment.save()
        second_comment.save()

        assert first_comment.article == article
        assert second_comment.article == article
        assert len(article.comments.all()) == 2
