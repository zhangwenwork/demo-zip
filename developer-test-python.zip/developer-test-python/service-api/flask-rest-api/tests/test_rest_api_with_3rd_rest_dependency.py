# test_rest_api_with_3rd_rest_dependency.py
import pytest
import requests

from rest_api_with_3rd_rest_dependency import app as myapp


@pytest.fixture
def app():
    app = myapp
    return app

class MockResponse:

    # mock json() method always returns a specific testing dictionary
    @staticmethod
    def json():
        return {"id": 4,
                "title": "mock server"}

def test_get_post_by_id(client, monkeypatch):
    # mock external post api
    # Any arguments may be passed and mock_get() will always return our
    # mocked object, which only has the .json() method.
    def mock_get(*args, **kwargs):
        if args[0] == 'https://jsonplaceholder.typicode.com/todos/4':
            return MockResponse()

    # apply the monkeypatch for requests.get to mock_get
    monkeypatch.setattr(requests, "get", mock_get)

    url = '/api/posts/4'
    res = client.get(url)
    assert res.json['id'] == 4
    assert res.json['title'] == 'mock server'
