# test_rest_api_without_dependency.py
import pytest

from rest_api_without_dependency import app as myapp


@pytest.fixture
def app():
    app = myapp
    return app

def test_name_slugify(client):
    data = {
        'name': 'this is the name'
    }
    url = '/api/slugify'
    res = client.post(url, json=data)
    assert res.json == 'this-is-the-name'
