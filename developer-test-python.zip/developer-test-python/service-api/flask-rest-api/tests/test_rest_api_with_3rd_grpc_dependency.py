# test_rest_api_with_3rd_grpc_dependency.py
import pytest

# from calculator_pb2_grpc import CalculatorStub
from calculator_pb2 import Number
import calculator_pb2_grpc
from rest_api_with_3rd_grpc_dependency import app as myapp


@pytest.fixture
def app():
    app = myapp
    return app

# Mock the gRpc service resposne
class Servicer(calculator_pb2_grpc.CalculatorServicer):
    def SquareRoot(self, request: Number, context) -> Number:
        return Number(value=6)

@pytest.fixture(scope='module')
def grpc_add_to_server():
    from calculator_pb2_grpc import add_CalculatorServicer_to_server

    return add_CalculatorServicer_to_server

@pytest.fixture(scope='module')
def grpc_servicer():
    return Servicer()


@pytest.fixture(scope='module')
def grpc_stub_cls(grpc_channel):
    from calculator_pb2_grpc import CalculatorStub

    return CalculatorStub

def test_calculator(client, mocker, grpc_stub):
    # mock external grpc api
    mocker.patch.object(calculator_pb2_grpc, 'CalculatorStub', return_value=grpc_stub)
    url = '/api/calculator/25'
    res = client.get(url)
    assert res.json == 6

