# rest_api_with_3rd_grpc_dependency.py
from flask import Flask, jsonify
import grpc
import calculator_pb2
import calculator_pb2_grpc

app = Flask(__name__)

# gRPC API Call
@app.route('/api/calculator/<num>')
def calculator(num):
    # open a gRPC channel
    channel = grpc.insecure_channel('localhost:50051')

    # create a stub (client)
    number = calculator_pb2.Number(value=int(num))
    response = calculator_pb2_grpc.CalculatorStub(channel).SquareRoot(number)
    return jsonify(response.value)
