#rest_api_with_3rd_rest_dependency.py
from flask import Flask
import requests

app = Flask(__name__)

# Rest API Call
@app.route('/api/posts/<id>')
def get_post_by_id(id):
    # call the 3rd party rest service to get the post
    post_url = "https://jsonplaceholder.typicode.com/todos/" + id
    r = requests.get(post_url)
    return r.json()
