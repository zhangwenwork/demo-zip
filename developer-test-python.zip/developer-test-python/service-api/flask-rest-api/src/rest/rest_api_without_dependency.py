# rest_api_without_dependency.py
from flask import request, jsonify
from slugify import slugify

from flask import Flask

app = Flask(__name__)

@app.route('/api/slugify', methods=['POST'])
def name_slugify():
    print(request.json)
    name = request.json["name"]
    return jsonify(slugify(name))
