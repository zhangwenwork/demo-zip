package com.contract.providerservice.rest;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = "/api/users", produces = APPLICATION_JSON_VALUE)
public class UserResource {

    @GetMapping
    ResponseEntity<List<ResponseDTO>> getUsersInfo(){
        List<ResponseDTO> usersInfo = buildUsersInfo();
        return ResponseEntity.ok(usersInfo);
    }

    private List<ResponseDTO> buildUsersInfo() {
        ResponseDTO fistUser = new ResponseDTO("1", "Sam", "22");
        ResponseDTO secondUser = new ResponseDTO("2", "Elly", "12");
        return Arrays.asList(fistUser, secondUser);
    }
}
