package com.contract.firstconsumerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstConsumerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
