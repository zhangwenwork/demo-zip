package com.contract.firstconsumerservice.service;

public class BasicUserInfo {
    private String id;
    private String name;

    public BasicUserInfo() {
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}
