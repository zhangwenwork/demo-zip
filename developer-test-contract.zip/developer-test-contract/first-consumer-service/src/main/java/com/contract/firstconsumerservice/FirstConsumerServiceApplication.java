package com.contract.firstconsumerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstConsumerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstConsumerServiceApplication.class, args);
	}

}
