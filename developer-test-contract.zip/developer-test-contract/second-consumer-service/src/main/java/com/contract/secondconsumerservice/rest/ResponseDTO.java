package com.contract.secondconsumerservice.rest;

public class ResponseDTO {
    private String id;
    private String name;
    private String age;
    private String description;

    public ResponseDTO(String id, String name, String age, String description) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAge() {
        return age;
    }

    public String getDescription() {
        return description;
    }
}
