package com.contract.secondconsumerservice.service;

public class BasicUserInfo {
    private String id;
    private String name;
    private String age;

    public BasicUserInfo() {
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAge() {
        return age;
    }
}
