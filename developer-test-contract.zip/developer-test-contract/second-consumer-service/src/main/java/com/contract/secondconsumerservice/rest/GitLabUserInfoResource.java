package com.contract.secondconsumerservice.rest;

import com.contract.secondconsumerservice.service.BasicUserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = "/api/users/gitlab", produces = APPLICATION_JSON_VALUE)
public class GitLabUserInfoResource {

    private final BasicUserService basicUserService;

    public GitLabUserInfoResource(BasicUserService basicUserService) {
        this.basicUserService = basicUserService;
    }

    @GetMapping
    ResponseEntity<List<ResponseDTO>> getUsersInfo(){
        List<ResponseDTO> usersInfo = buildUsersInfo();
        return ResponseEntity.ok(usersInfo);
    }

    private List<ResponseDTO> buildUsersInfo() {
        return basicUserService.basicUsersInfo().stream()
                .map(basicUserInfo -> new ResponseDTO(basicUserInfo.getId(),
                        basicUserInfo.getName(), basicUserInfo.getAge(), "Gitlab User")).collect(Collectors.toList());
    }

}
