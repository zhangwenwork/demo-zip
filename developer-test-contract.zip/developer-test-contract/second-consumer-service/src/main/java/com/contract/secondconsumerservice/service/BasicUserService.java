package com.contract.secondconsumerservice.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Service
public class BasicUserService {

    public static final String BASE = "http://localhost:8080";
    private String baseUrl = BASE;

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }
    public List<BasicUserInfo> basicUsersInfo() {
        WebClient client = WebClient.create(getBaseUrl());
        WebClient.RequestHeadersSpec<?> uri = client
                .get()
                .uri("/api/users");

        ResponseEntity<List<BasicUserInfo>> basicUsersInfoEntity = uri
                .header(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .accept(APPLICATION_JSON)
                .retrieve().toEntityList(BasicUserInfo.class)
                .block();

        return basicUsersInfoEntity.getBody();
    }

}
