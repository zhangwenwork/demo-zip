package com.contract.secondconsumerservice.pact;

import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit.PactProviderRule;
import au.com.dius.pact.consumer.junit.PactVerification;
import au.com.dius.pact.core.model.RequestResponsePact;
import au.com.dius.pact.core.model.annotations.Pact;
import com.contract.secondconsumerservice.service.BasicUserInfo;
import com.contract.secondconsumerservice.service.BasicUserService;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SecondConsumerPactTest {

    @Autowired
    BasicUserService basicUserService;

    @Rule
    public PactProviderRule mockProvider = new PactProviderRule("test_provider", this);

    @Pact(provider="test_provider", consumer="test_second_consumer")
    public RequestResponsePact createPact(PactDslWithProvider builder) {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("Content-Type", "application/json");


        return builder
                .given("")
                .uponReceiving("Pact JVM example Pact interaction")
                .path("/api/users")
                .method("GET")
                .willRespondWith()
                .headers(headers)
                .status(200)
                .body("[\n" +
                        "  {\n" +
                        "    \"id\": \"1\",\n" +
                        "    \"name\": \"Sam\",\n" +
                        "    \"age\": \"22\"\n" +
                        "  },\n" +
                        "  {\n" +
                        "    \"id\": \"2\",\n" +
                        "    \"name\": \"Elly\",\n" +
                        "    \"age\": \"12\"\n" +
                        "  }\n" +
                        "]")
                .toPact();
    }

    @Test
    @PactVerification("test_provider")
    public void runTest() {
        basicUserService.setBaseUrl(mockProvider.getUrl());
        List<BasicUserInfo> basicUsersInfo = basicUserService.basicUsersInfo();
        assertEquals(basicUsersInfo.get(1).getName(), "Elly");

    }
}
