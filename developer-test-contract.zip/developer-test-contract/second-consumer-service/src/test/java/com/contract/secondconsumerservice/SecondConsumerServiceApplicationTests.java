package com.contract.secondconsumerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondConsumerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
