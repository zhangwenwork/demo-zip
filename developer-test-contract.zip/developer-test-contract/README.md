# 微服务间的契约测试

# RESTful API场景下的契约测试

契约测试是在外部服务边界进行的测试，以验证它是否符合消费服务所期望的契约。

每当一些消费者连接到一个组件的接口来使用它的行为时，他们之间就形成了一个契约。该契约包含输入和输出数据结构、副作用(side effort)、性能和并发特性的期望。

组件的每个消费者根据其需求形成不同的契约。如果组件会随时间而发生变化，那么继续满足每个使用者的契约是很重要的。

集成契约测试提供了一种机制来显式验证组件是否满足契约。

当涉及的组件是微服务时，接口是每个服务公开的公共API。每个消费服务的维护者编写一个独立的测试套件，仅验证正在使用的生产服务的那些方面。

这些测试不是组件测试。它们没有深入测试服务的行为，但是服务调用的输入和输出包含必需的属性，并且响应延迟和吞吐量在可接受的范围内。

理想情况下，由每个消费团队编写的契约测试套件被打包并可在用于生成服务的构建管道中运行。通过这种方式，生产服务的维护者知道他们的更改对他们的使用者的影响。

> Java Code Demo: developer-test-contract

下面是一个contract test的示例

<img src="readme-pic/1.png" width="450" height="400" />

# Demo目录

### Comsumer

- [first-consumer-service](https://github.com/zhangwenwork/developer-test-contract/tree/master/first-consumer-service)
- [second-consumer-service](https://github.com/zhangwenwork/developer-test-contract/tree/master/second-consumer-service)

### Provider

- [provider-service](https://github.com/zhangwenwork/developer-test-contract/tree/master/provider-service)

### Pact Brocker

- [brocker-service](https://github.com/zhangwenwork/developer-test-contract/tree/master/brocker-service)

  启动Pact broker server

  ```
  docker-compose up -d
  ```

  启动后，可浏览器直接访问http://localhost/查看契约

  例如，访问http://localhost/groups/test_first_consumer可看到服务间的依赖关系

  <img src="readme-pic/5.png" width="400" height="300" />

  访问http://localhost/pacts/provider/test_provider/consumer/test_first_consumer/latest可看到契约定义

  <img src="readme-pic/6.png" width="400" height="350" />

------



## Contract Test

<img src="readme-pic/2.png" width="450" height="200" />

### **Consumer**：

Service的使用者，向provider发起HTTP请求来获取数据；

### **Provider**：

Service的提供者，接收consumer的HTTP请求并返回数据；

### **Contract**：

契约，一种定义在 consumer与provider之间的交互方式；

## **Pact - Consumer** **测试**

<img src="readme-pic/3.png" width="500" height="250" />

## **Pact - Provider** **测试**

<img src="readme-pic/4.png" width="500" height="250" />