package com.serviceapiwith3rdpartygrpcdependency.outbound;

import io.grpc.Channel;
import io.grpc.StatusRuntimeException;

/**
 */

public class DogpayClient {

  private final PaymentGrpc.PaymentBlockingStub blockingStub;
  public DogpayClient(Channel channel) {
    blockingStub = PaymentGrpc.newBlockingStub(channel);
  }

  public String pay(String amount) {
    DogpayRequest request = DogpayRequest.newBuilder().setAmount(amount)
            .setReturnUrl("https://example.com/returnURL.htm")
            .setCurrencyCode("en_US")
            .setReceiverEmail("david@example.com")
            .setCancelUrl("https://example.com/cancelURL.htm")
            .setActionType("PAY").build();
    DogReply response;
    try {
      response = blockingStub.pay(request);
      return response.toString();
    } catch (StatusRuntimeException e) {
      return "error";
    }

  }

}
