package com.serviceapiwith3rdpartygrpcdependency.inbound.rest;


import com.serviceapiwith3rdpartygrpcdependency.outbound.DogpayGateway;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = "/payment", produces = APPLICATION_JSON_VALUE)
public class PaymentResource {
    private final DogpayGateway dogpayGateway;

    public PaymentResource(DogpayGateway dogpayGateway) {
        this.dogpayGateway = dogpayGateway;
    }


    @PostMapping(value = "/buy-me-a-coffee-request", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> post(@RequestBody BuyMeACoffeeRequest data) throws InterruptedException {
        String responseMessage;
        responseMessage = dogpayGateway.pay(data.getAmount());

        return ResponseEntity.ok("Thanks the coffee, you'r using: " + responseMessage);
    }
}
