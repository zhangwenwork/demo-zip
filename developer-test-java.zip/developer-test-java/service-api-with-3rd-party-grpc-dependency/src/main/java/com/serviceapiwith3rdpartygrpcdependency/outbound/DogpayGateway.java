package com.serviceapiwith3rdpartygrpcdependency.outbound;

import io.grpc.ManagedChannel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class DogpayGateway{

    @Autowired
    public ChannelBuilder channelBuilder;


    public String pay(String amount) throws InterruptedException {

        String response;
        ManagedChannel channel = channelBuilder.buildChannel();

        try {
            DogpayClient client = new DogpayClient(channel);
            response = client.pay(amount);
        } finally {
            channel.shutdownNow().awaitTermination(5, TimeUnit.SECONDS);
        }

        return "dogpay: " + response;
    }

}
