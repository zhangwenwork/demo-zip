package com.serviceapiwith3rdpartygrpcdependency.outbound;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ChannelBuilder {
    @Autowired
    public DogpayServerConfiguration configuration;
    public static final String BASE_URL = "localhost";

    public ManagedChannel buildChannel() {
        String target = BASE_URL + ":" + configuration.getPort();
        return ManagedChannelBuilder.forTarget(target)
                .usePlaintext()
                .build();
    }
}
