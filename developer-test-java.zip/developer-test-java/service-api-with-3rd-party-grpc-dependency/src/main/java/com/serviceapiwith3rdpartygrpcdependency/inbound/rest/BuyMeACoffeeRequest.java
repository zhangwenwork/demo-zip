package com.serviceapiwith3rdpartygrpcdependency.inbound.rest;

import lombok.Getter;

@Getter
public class BuyMeACoffeeRequest {
    public PaymentType paymentType;
    public String amount;

    public enum PaymentType {
        CATPAY,
        DOGPAY
    }
}
