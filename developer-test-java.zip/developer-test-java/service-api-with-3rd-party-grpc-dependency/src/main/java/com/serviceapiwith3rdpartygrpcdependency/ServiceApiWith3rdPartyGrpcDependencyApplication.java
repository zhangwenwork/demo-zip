package com.serviceapiwith3rdpartygrpcdependency;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceApiWith3rdPartyGrpcDependencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceApiWith3rdPartyGrpcDependencyApplication.class, args);
	}

}
