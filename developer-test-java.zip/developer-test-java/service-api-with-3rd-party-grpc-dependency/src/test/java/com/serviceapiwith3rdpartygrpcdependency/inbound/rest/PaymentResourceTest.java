package com.serviceapiwith3rdpartygrpcdependency.inbound.rest;

import com.serviceapiwith3rdpartygrpcdependency.outbound.ChannelBuilder;
import com.serviceapiwith3rdpartygrpcdependency.outbound.DogReply;
import com.serviceapiwith3rdpartygrpcdependency.outbound.DogpayRequest;
import com.serviceapiwith3rdpartygrpcdependency.outbound.PaymentGrpc;
import io.grpc.BindableService;
import io.grpc.inprocess.InProcessChannelBuilder;
import io.grpc.inprocess.InProcessServerBuilder;
import io.grpc.stub.StreamObserver;
import io.grpc.testing.GrpcCleanupRule;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.WebApplicationContext;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@RunWith(SpringRunner.class)
public class PaymentResourceTest {
    @LocalServerPort
    private int port;

    @Rule
    public GrpcCleanupRule grpcCleanup = new GrpcCleanupRule();

    @MockBean
    public ChannelBuilder channel;


    @Autowired
    private WebApplicationContext webApplicationContext;

    private final String serverName = InProcessServerBuilder.generateName();

    @Before
    public void setUp() throws Exception {
        // 配置 RestAssured 使用随机端口
        RestAssured.port = port;
        RestAssuredMockMvc.webAppContextSetup(webApplicationContext);

    }

    public static final String PAYMENT_BASE_PATH = "/payment";
    public static final String COFFEE_PATH = PAYMENT_BASE_PATH + "/" + "buy-me-a-coffee-request";

    @Value("classpath:payload/dogpay_request.json")
    Resource dogpayRequest;

    @Test
    public void should_pay_when_using_dogpay() throws Exception {
        addService(serverName, new PaymentImpl());
        when(channel.buildChannel()).thenReturn(InProcessChannelBuilder
                .forName(serverName).build());

        String response = given()
                .contentType(ContentType.JSON)
                .body(dogpayRequest.getFile())
                .post(COFFEE_PATH)
                .then()
                .assertThat()
                .statusCode(HttpStatus.OK.value())
                .extract()
                .asString();

        assertThat(response, containsString("CREATE"));
    }

    //add the mock service to in process server
    private void addService(String name, BindableService service) throws Exception {
        // Create a server, add service, start, and register for automatic graceful shutdown.
        grpcCleanup.register(InProcessServerBuilder
                .forName(name).directExecutor().addService(service).build().start());
    }

    //Mock the gRpc service dependency response
    static class PaymentImpl extends PaymentGrpc.PaymentImplBase {

        @Override
        public void pay(DogpayRequest request, StreamObserver<DogReply> responseObserver) {
            DogReply reply = DogReply.newBuilder().setTimestamp("2009-10-06T14:30:39.383-07:00")
                    .setAck("Success")
                    .setCorrelationId("cfe8f8783f1d3")
                    .setPayKey("AP-17266198048308436")
                    .setPaymentExecStatus("CREATED").build();
            responseObserver.onNext(reply);
            responseObserver.onCompleted();
        }
    }
}
