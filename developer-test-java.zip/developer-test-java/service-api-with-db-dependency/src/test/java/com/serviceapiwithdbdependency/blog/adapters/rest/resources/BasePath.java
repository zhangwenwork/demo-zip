package com.serviceapiwithdbdependency.blog.adapters.rest.resources;

public class BasePath {
    public static final String BLOG_BASE_PATH = "/blog";
    public static final String PUBLISHED_BLOG_BASE_PATH = "/published-blog";
    public static final String PAYMENT_BASE_PATH = "/payment";
}
