package com.serviceapiwithdbdependency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceApiWithDbDependencyApplicationTests {

	@Test
	void contextLoads() {
	}

}
