package com.serviceapiwithdbdependency.blog.adapters.rest.resources;

public interface ResponseDto {
}
