package com.serviceapiwithdbdependency;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceApiWithDbDependencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceApiWithDbDependencyApplication.class, args);
	}

}
