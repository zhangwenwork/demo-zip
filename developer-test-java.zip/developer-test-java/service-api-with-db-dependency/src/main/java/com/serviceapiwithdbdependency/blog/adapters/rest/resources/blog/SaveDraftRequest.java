package com.serviceapiwithdbdependency.blog.adapters.rest.resources.blog;


import com.serviceapiwithdbdependency.blog.adapters.rest.resources.RequestDto;

class SaveDraftRequest implements RequestDto {
    public String title;
    public String body;
}
