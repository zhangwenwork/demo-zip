package com.serviceapiwith3rdpartyrestdependency.inbound.rest;

import io.restassured.http.ContentType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.client.MockServerClient;
import org.mockserver.junit.jupiter.MockServerExtension;
import org.mockserver.junit.jupiter.MockServerSettings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;

import java.io.IOException;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;
import static org.mockserver.model.JsonBody.json;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@ExtendWith({MockServerExtension.class})
@MockServerSettings(ports = {9002})
@DisplayName("/payment")
class PaymentResourceTest extends ResourceTest {

    public static final String COFFEE_PATH = "/payment" + "/" + "buy-me-a-coffee-request";

    @Value("classpath:payload/catpay_request.json")
    Resource catpayRequest;

    @Value("classpath:payload/catpay_service_mock_request.json")
    Resource mockCatpayRequest;
    @Value("classpath:payload/catpay_service_mock_response.json")
    Resource mockCatpayResponse;

    @Test
    void should_pay_when_using_catpay(MockServerClient client) throws IOException {
        //mock the 3rd party catpay service
        mockThe3rdPartyService(client);

        String response = given()
                .contentType(ContentType.JSON)
                .body(catpayRequest.getFile())
                .post(COFFEE_PATH)
                .then()
                .assertThat()
                .statusCode(HttpStatus.OK.value())
                .extract()
                .asString();

        assertThat(response, containsString("Thanks the coffee, you'r using: catpay"));
        assertThat(response, containsString("17266198048308436"));
    }

    private void mockThe3rdPartyService(MockServerClient client) throws IOException {
        client
            .when(
                request()
                    .withMethod("POST")
                    .withPath("/catpay/pay-request")
                    .withHeader(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                    .withBody(json(readFile(mockCatpayRequest)))
            )
            .respond(
                response()
                    .withBody(json(readFile(mockCatpayResponse)))
            );
    }
}
