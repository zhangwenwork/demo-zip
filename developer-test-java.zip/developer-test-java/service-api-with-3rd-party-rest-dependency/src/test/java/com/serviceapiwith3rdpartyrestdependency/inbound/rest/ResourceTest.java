package com.serviceapiwith3rdpartyrestdependency.inbound.rest;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.net.URL;

import static com.google.common.io.Resources.getResource;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public abstract class ResourceTest {

    // 注入分配的随机端口供测试代码使用
    @LocalServerPort
    private int port;

    @BeforeEach
    void init() {
        // 配置 RestAssured 使用随机端口
        RestAssured.port = port;
    }

    protected String readFile(Resource resource) throws IOException {
        //Java 11 readString
//        return Files.readString(resource.getFile().toPath());
//        File file = new File("test.txt");

        return Resources.toString(resource.getURL(), Charsets.UTF_8);
    }
}
