package com.serviceapiwith3rdpartyrestdependency.outbound.gateway;

public class RequestEnvelope {
    public String errorLanguage;
}
