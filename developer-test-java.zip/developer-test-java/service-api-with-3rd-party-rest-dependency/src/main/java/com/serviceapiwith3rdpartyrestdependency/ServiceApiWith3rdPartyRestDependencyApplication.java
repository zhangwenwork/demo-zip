package com.serviceapiwith3rdpartyrestdependency;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceApiWith3rdPartyRestDependencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceApiWith3rdPartyRestDependencyApplication.class, args);
	}

}
