package com.serviceapiwith3rdpartyrestdependency.outbound.gateway;

import java.util.List;

public class CatpayRequest {
    public String returnUrl;

    public RequestEnvelope requestEnvelope;
    public String currencyCode;
    public List<Receiver> receiver;
    public String cancelUrl;
    public ActionType actionType;

    public CatpayRequest(List<Receiver> receiver, ActionType actionType, String currencyCode) {
        this.currencyCode = currencyCode;
        this.receiver = receiver;
        this.actionType = actionType;
    }

    public enum ActionType {
        PAY,
        CREATE,
        PAY_PRIMARY
    }
}
