package com.serviceapiwith3rdpartyrestdependency.inbound.rest;

public class BuyMeACoffeeRequest {
    public PaymentType paymentType;
    public String amount;

    public enum PaymentType {
        CATPAY,
        DOGPAY
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    public String getAmount() {
        return amount;
    }
}
