package com.serviceapiwith3rdpartyrestdependency.outbound.gateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ReactiveHttpOutputMessage;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Collections;

import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
public class CatpayGateway{
    public static final String BASE_URL = "http://localhost";
    public static final String CATPAY_PAY_REQUEST = "/catpay/pay-request";
    @Autowired
    public CatpayServerConfiguration configuration;

    public String pay(String amount) {
        WebClient client = WebClient.create(BASE_URL + ":" + configuration.getPort());
        WebClient.RequestBodySpec uri = client
                .post()
                .uri(CATPAY_PAY_REQUEST);

        BodyInserter<Object, ReactiveHttpOutputMessage> inserter
                = BodyInserters.fromObject(buildCatpayRequest(amount));

        String response = uri
                .body(inserter)
                .header(CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .accept(APPLICATION_JSON)
                .retrieve().bodyToMono(String.class)
                .block();

        return "catpay: " + response;
    }

    private CatpayRequest buildCatpayRequest(String amount) {
        Receiver receiver = new Receiver("demo@example.com", amount);
        return new CatpayRequest(Collections.singletonList(receiver),
                 CatpayRequest.ActionType.PAY,"USD");

    }
}
