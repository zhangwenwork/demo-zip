package com.serviceapiwith3rdpartyrestdependency.inbound.rest;


import com.serviceapiwith3rdpartyrestdependency.outbound.gateway.CatpayGateway;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = "/payment", produces = APPLICATION_JSON_VALUE)
public class PaymentResource {
    private final CatpayGateway catpayGateway;

    public PaymentResource(CatpayGateway catpayGateway) {
        this.catpayGateway = catpayGateway;
    }


    @PostMapping(value = "/buy-me-a-coffee-request", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> post(@RequestBody BuyMeACoffeeRequest data) {
        String responseMessage;
        responseMessage = catpayGateway.pay(data.getAmount());

        return ResponseEntity.ok("Thanks the coffee, you'r using: " + responseMessage);
    }
}
