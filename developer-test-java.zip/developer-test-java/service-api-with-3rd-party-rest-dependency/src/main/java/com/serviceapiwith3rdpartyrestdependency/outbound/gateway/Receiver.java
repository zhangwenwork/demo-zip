package com.serviceapiwith3rdpartyrestdependency.outbound.gateway;

public class Receiver {
    public String email;
    public String amount;

    public Receiver() {
    }

    public Receiver(String email, String amount) {
        this.email = email;
        this.amount = amount;
    }

    public String getEmail() {
        return email;
    }

    public String getAmount() {
        return amount;
    }
}
