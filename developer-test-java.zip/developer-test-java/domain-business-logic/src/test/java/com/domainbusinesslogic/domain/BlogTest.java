package com.domainbusinesslogic.domain;

import com.domainbusinesslogic.domain.exceptions.NoNeedToPublishException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class BlogTest {


    @Nested
    class constructor {

        @Test
        void should_initialize_correctly() {
            UUID authorId = UUID.randomUUID();

            Blog blog = new Blog("Test Blog", "Something...", authorId);

            assertThat(blog.getId()).isNotNull();
            assertThat(blog.getTitle()).isEqualTo("Test Blog");
            assertThat(blog.getBody()).isEqualTo("Something...");
            assertThat(blog.getAuthorId()).isEqualTo(authorId);
            assertThat(blog.getStatus()).isEqualTo(Blog.Status.Draft);
            assertThat(blog.getCreatedAt()).isNotNull();
            assertThat(blog.getSavedAt()).isEqualTo(blog.getCreatedAt());
            assertThat(blog.getPublished()).isNull();
        }

        @Test
        void should_throw_IllegalArgumentException_when_title_is_null_or_no_content() {
            assertThatThrownBy(() -> new Blog(null, "Something...", UUID.randomUUID()))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessage("the title cannot be null or no content");
            assertThatThrownBy(() -> new Blog("   ", "Something...", UUID.randomUUID()))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessage("the title cannot be null or no content");
        }

        @Test
        void should_throw_IllegalArgumentException_when_author_is_null() {
            assertThatThrownBy(() -> new Blog("Test Blog", "Something...", null))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessage("the author cannot be null");
        }
    }

    @Nested
    class saveDraft {

        private Blog blog;
        private Instant pastSavedAt;

        @BeforeEach
        void setUp() {
            blog = new Blog("Test Blog", "Something...", UUID.randomUUID());
            pastSavedAt = blog.getSavedAt();
        }

        @Test
        void should_save_correctly() throws InterruptedException {

            blog.saveDraft("Updated Title", "Updated...");

            assertThat(blog.getTitle()).isEqualTo("Updated Title");
            assertThat(blog.getBody()).isEqualTo("Updated...");
            assertThat(blog.getSavedAt()).isAfter(pastSavedAt);
        }

        @Test
        void should_throw_IllegalArgumentException_when_title_is_null_or_no_content() {
            assertThatThrownBy(() -> blog.saveDraft(null, "Updated..."))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessage("the title cannot be null or no content");
            assertThatThrownBy(() -> blog.saveDraft("   ", "Updated..."))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessage("the title cannot be null or no content");
        }

    }

    @Nested
    class publish {

        private Blog blog;

        @BeforeEach
        void setUp() {
            blog = new Blog("Test Blog", "Something...", UUID.randomUUID());
        }

        @Test
        void should_publish_correctly() {
            blog.publish();

            assertThat(blog.getStatus()).isEqualTo(Blog.Status.Published);
            PublishedBlog published = blog.getPublished();
            assertThat(published.getTitle()).isEqualTo("Test Blog");
            assertThat(published.getBody()).isEqualTo("Something...");
            assertThat(published.getPublishedAt()).isNotNull();
        }

        @Test
        void should_throw_NoNeedToPublishException_when_no_change() {
            blog.publish();
            blog.saveDraft(blog.getTitle(), blog.getBody());

            assertThatThrownBy(blog::publish)
                    .isInstanceOf(NoNeedToPublishException.class)
                    .hasMessage("no need to publish");
        }
    }

    @Nested
    class isPublished {

        private Blog blog;

        @BeforeEach
        void setUp() {
            blog = new Blog("Test Blog", "Something...", UUID.randomUUID());
        }

        @Test
        void should_return_correct_result() {
            assertThat(blog.isPublished()).isFalse();
            blog.publish();
            assertThat(blog.isPublished()).isTrue();
        }
    }

}
