package com.domainbusinesslogic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DomainBusinessLogicApplicationTests {

	@Test
	void contextLoads() {
	}

}
