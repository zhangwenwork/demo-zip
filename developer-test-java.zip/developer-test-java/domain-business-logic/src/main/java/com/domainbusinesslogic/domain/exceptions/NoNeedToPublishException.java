package com.domainbusinesslogic.domain.exceptions;

public class NoNeedToPublishException extends RuntimeException {
    public NoNeedToPublishException() {
        super("no need to publish");
    }
}
