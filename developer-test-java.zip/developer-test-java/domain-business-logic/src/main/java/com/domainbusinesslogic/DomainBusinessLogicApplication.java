package com.domainbusinesslogic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DomainBusinessLogicApplication {

	public static void main(String[] args) {
		SpringApplication.run(DomainBusinessLogicApplication.class, args);
	}

}
