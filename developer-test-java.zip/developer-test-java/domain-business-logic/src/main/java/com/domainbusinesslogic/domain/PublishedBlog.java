package com.domainbusinesslogic.domain;

import java.time.Instant;

public class PublishedBlog{
    private final String title;
    private final String body;
    private final Instant publishedAt;

    public PublishedBlog(String title, String body, Instant publishedAt) {
        this.title = title;
        this.body = body;
        this.publishedAt = publishedAt;
    }

    public String getTitle() {
        return title;
    }

    public String getBody() {
        return body;
    }

    public Instant getPublishedAt() {
        return publishedAt;
    }
}
