package com.serviceapiwithoutdependency.rest.blog;

import java.time.Instant;
import java.util.UUID;

class BlogDto {
    private UUID id;
    private String title;
    private String body;
    private UUID authorId;
    private Instant createdAt;
    private Instant savedAt;

    public BlogDto(UUID id, String title, String body, UUID authorId, Instant createdAt, Instant savedAt) {
        this.id = id;
        this.title = title;
        this.body = body;
        this.authorId = authorId;
        this.createdAt = createdAt;
        this.savedAt = savedAt;
    }

    public BlogDto() {

    }

    public UUID getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getBody() {
        return body;
    }

    public UUID getAuthorId() {
        return authorId;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getSavedAt() {
        return savedAt;
    }
}
