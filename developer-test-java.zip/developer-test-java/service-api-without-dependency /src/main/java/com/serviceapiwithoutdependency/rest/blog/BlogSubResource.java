package com.serviceapiwithoutdependency.rest.blog;

import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.UUID;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(value = "/blog/{id}", produces = APPLICATION_JSON_VALUE)
public class BlogSubResource {

    @GetMapping
    public BlogDto get(@PathVariable UUID id) {
        return new BlogDto(id, "Service API", "Service API test with out dependency",
                UUID.randomUUID(), Instant.now(), Instant.now());
    }

}
