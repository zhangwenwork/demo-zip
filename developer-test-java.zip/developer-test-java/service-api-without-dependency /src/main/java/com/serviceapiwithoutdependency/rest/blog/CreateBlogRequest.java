package com.serviceapiwithoutdependency.rest.blog;

class CreateBlogRequest{
    public String title;
    public String body;
    public String authorId;
}
