package com.serviceapiwithoutdependency;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceApiWithoutDependencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceApiWithoutDependencyApplication.class, args);
	}

}
