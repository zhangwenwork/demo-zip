package com.serviceapiwithoutdependency.rest.blog;

import com.google.common.collect.ImmutableMap;
import com.serviceapiwithoutdependency.rest.ResourceTest;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static com.serviceapiwithoutdependency.rest.BaseResponseSpecification.CREATED_SPEC;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;


@DisplayName("/blog")
class BlogResourceTest extends ResourceTest {
    @Nested
    @DisplayName("POST /blog")
    class post {

        @Test
        void should_create_blog() {
            UUID authorId = UUID.randomUUID();
            given()
                    .contentType(ContentType.JSON)
                    .body(ImmutableMap.of(
                            "title", "Test Blog",
                            "body", "Something...",
                            "authorId", authorId
                    ))
                    .when()
                    .post("/blog")
                    .then()
                    .spec(CREATED_SPEC)
                    .body("id", notNullValue())
                    .body("title", is("Test Blog"))
                    .body("body", is("Something..."))
                    .body("authorId", is(authorId.toString()))
                    .header("Location", response -> containsString("/blog" + "/" + response.path("id")));
        }
    }

}
