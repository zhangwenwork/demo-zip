package com.serviceapiwithoutdependency.rest;

import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.http.ContentType.JSON;
import static org.springframework.http.HttpStatus.*;

public class BaseResponseSpecification {

    public static ResponseSpecification OK_SPEC = new ResponseSpecBuilder()
            .expectStatusCode(OK.value())
            .expectContentType(JSON)
            .build();

    public static ResponseSpecification CREATED_SPEC = new ResponseSpecBuilder()
            .expectStatusCode(CREATED.value())
            .expectContentType(JSON)
            .build();


}
