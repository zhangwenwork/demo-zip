package com.serviceapiwithoutdependency.rest.blog;

import com.serviceapiwithoutdependency.rest.ResourceTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static com.serviceapiwithoutdependency.rest.BaseResponseSpecification.OK_SPEC;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

@DisplayName("/blog" + "/{id}")
class BlogSubResourceTest extends ResourceTest {

    @Nested
    @DisplayName("GET " + "/blog" + "/{id}")
    class get {

        @Test
        void should_get_blog() {
            String blogId = UUID.randomUUID().toString();
            given()
                    .when()
                    .get("/blog" + "/" + blogId)
                    .then()
                    .spec(OK_SPEC)
                    .body("id", is(blogId))
                    .body("title", is("Service API"))
                    .body("body", is("Service API test with out dependency"))
                    .body("authorId", notNullValue());
        }

    }

}
